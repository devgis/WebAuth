﻿using System.Collections.Generic;

namespace MovieDemo.ViewModels
{
    public class MovieTypeListViewModel
    {
        public IEnumerable<Models.MovieType> MovieTypes { get; set; }
    }
}