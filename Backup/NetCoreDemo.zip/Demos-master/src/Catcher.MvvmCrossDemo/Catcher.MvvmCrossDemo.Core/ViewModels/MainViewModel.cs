﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MvvmCross.Core.ViewModels;

namespace Catcher.MvvmCrossDemo.Core.ViewModels
{
    public class MainViewModel : MvxViewModel
    {

        public MainViewModel()
        { }
    }
}
